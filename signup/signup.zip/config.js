module.exports={
    UserPoolId : 'us-east-2_TSo0fjBmQ', // Your user pool id here
    ClientId : '3fkne2plvv1bhsluicmojtt4sm', // Your client id here
    
}