const AmazonCognitoIdentity = require('amazon-cognito-identity-js-node');
const CognitoUserPool = AmazonCognitoIdentity.CognitoUserPool;
const CognitoUserAttribute = AmazonCognitoIdentity.CognitoUserAttribute;
const { UserPoolId, ClientId } = require('./config');
const { getBodyData } = require('./utils');


exports.handler = async (event, context, callback) => {
  context.callbackWaitsForEmptyEventLoop = false;
  try {
    const poolData = {
      UserPoolId: UserPoolId,
      ClientId: ClientId,
    };
    const userPool = new CognitoUserPool(poolData);
     let reqBody = getBodyData(event);
     console.log(JSON.stringify(event));

    // Define User Attributes
    const attributeList = [];
    const dataEmail = {
      "Name": "email",
      "Value": reqBody.email

    };
    const dataName = {
      "Name": 'name',
      "Value": reqBody.name
    };

    const dataPhone = {
      "Name": 'phone_number',
      "Value": reqBody.phone_number
    };

    attributeList.push(new CognitoUserAttribute(dataEmail.Name, dataEmail.Value));
    attributeList.push(new CognitoUserAttribute(dataPhone.Name, dataPhone.Value));
    attributeList.push(new CognitoUserAttribute(dataName.Name, dataName.Value));
    userPool.signUp(reqBody.email, reqBody.password, attributeList, null, function (err, result) {
      if (err) {
        return callback({ status: false, message: 'Something went wrong', err: err }, null);
      }
      callback(null, { status: true, message: "Request proceesed sucessfully" });

    });

  } catch (err) {
    console.log('err',err);
    callback({ status: false, message: 'Something went wrong', err: err }, null);

  }

}

